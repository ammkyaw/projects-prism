(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_sprints_planning_page_tsx_76c4b1a8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_sprints_planning_page_tsx_76c4b1a8._.js",
  "chunks": [
    "static/chunks/src_234bc0bd._.js",
    "static/chunks/node_modules_date-fns_67bade50._.js",
    "static/chunks/node_modules_react-day-picker_dist_index_esm_9fc30424.js",
    "static/chunks/node_modules_lodash_f240f67a._.js",
    "static/chunks/node_modules_recharts_es6_8235043b._.js",
    "static/chunks/node_modules_c807037a._.js"
  ],
  "source": "dynamic"
});
