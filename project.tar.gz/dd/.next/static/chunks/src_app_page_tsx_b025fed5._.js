(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_app_page_tsx_b025fed5._.js", {

"[project]/src/app/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"); // Added useRef, React
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/xlsx/xlsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)"); // Import buttonVariants
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [app-client] (ecmascript)"); // Added CardContent
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript) <export default as Download>"); // Added ArrowUpDown, ListChecks icons
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$no$2d$axes$2d$column$2d$increasing$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chart-no-axes-column-increasing.js [app-client] (ecmascript) <export default as BarChart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListPlus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/list-plus.js [app-client] (ecmascript) <export default as ListPlus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-plus.js [app-client] (ecmascript) <export default as PlusCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/notebook-pen.js [app-client] (ecmascript) <export default as NotebookPen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2d$days$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarDays$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/calendar-days.js [app-client] (ecmascript) <export default as CalendarDays>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/square-pen.js [app-client] (ecmascript) <export default as Edit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2d$round$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UsersRound$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/users-round.js [app-client] (ecmascript) <export default as UsersRound>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/package.js [app-client] (ecmascript) <export default as Package>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$dashboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutDashboard$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/layout-dashboard.js [app-client] (ecmascript) <export default as LayoutDashboard>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$iteration$2d$cw$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IterationCw$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/iteration-cw.js [app-client] (ecmascript) <export default as IterationCw>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Layers$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/layers.js [app-client] (ecmascript) <export default as Layers>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChartBig$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chart-column-big.js [app-client] (ecmascript) <export default as BarChartBig>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/settings.js [app-client] (ecmascript) <export default as Settings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-client] (ecmascript) <export default as Eye>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$git$2d$commit$2d$vertical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GitCommitVertical$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/git-commit-vertical.js [app-client] (ecmascript) <export default as GitCommitVertical>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$history$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__History$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/history.js [app-client] (ecmascript) <export default as History>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/tabs.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/alert-dialog.tsx [app-client] (ecmascript)");
// Main Content Components (Tabs) - Renamed and New Placeholders
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$dashboard$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/dashboard-tab.tsx [app-client] (ecmascript)"); // Renamed from HomeTab
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$backlog$2f$backlog$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/backlog/backlog-tab.tsx [app-client] (ecmascript)"); // Updated path
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$backlog$2f$backlog$2d$grooming$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/backlog/backlog-grooming-tab.tsx [app-client] (ecmascript)"); // Corrected import path
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$backlog$2f$history$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/backlog/history-tab.tsx [app-client] (ecmascript)"); // Import HistoryTab component
// Team and Settings Tabs
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$teams$2f$members$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/teams/members-tab.tsx [app-client] (ecmascript)"); // Updated path
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$settings$2f$holidays$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/settings/holidays-tab.tsx [app-client] (ecmascript)"); // Updated path
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$teams$2f$teams$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/teams/teams-tab.tsx [app-client] (ecmascript)"); // Updated path
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$add$2d$members$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/add-members-dialog.tsx [app-client] (ecmascript)");
// Sprint Sub-Tab Components
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$sprints$2f$sprint$2d$summary$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/sprints/sprint-summary-tab.tsx [app-client] (ecmascript)"); // Updated path
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$sprints$2f$sprint$2d$planning$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/sprints/sprint-planning-tab.tsx [app-client] (ecmascript)"); // New component for planning
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$sprints$2f$sprint$2d$retrospective$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/sprints/sprint-retrospective-tab.tsx [app-client] (ecmascript)"); // Updated path
// Analytics Sub-Tab Components
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$analytics$2d$charts$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/analytics-charts-tab.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$analytics$2f$analytics$2d$reports$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/analytics/analytics-reports-tab.tsx [app-client] (ecmascript)"); // Updated path
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/types/sprint-data.ts [app-client] (ecmascript)"); // Import taskPriorities
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/parseISO.mjs [app-client] (ecmascript)"); // Added getYear
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isPast$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/isPast.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isValid$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/isValid.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$getYear$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/getYear.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$mode$2d$toggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/mode-toggle.tsx [app-client] (ecmascript)"); // Import ModeToggle
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Helper function to generate the next backlog ID based on *all* items (including historical and unsaved)
const generateNextBacklogIdHelper = (allProjectBacklogItems)=>{
    const currentYear = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$getYear$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getYear"])(new Date()).toString().slice(-2); // Get last two digits of the year
    const prefix = `BL-${currentYear}`;
    let maxNum = 0;
    allProjectBacklogItems.forEach((item)=>{
        const id = item.backlogId; // Use the actual backlogId
        // Consider only base BL-YYxxxx IDs from the current year
        // Use regex to extract the numeric part more reliably
        const match = id?.match(/^BL-\d{2}(\d{4})(?:-.*)?$/); // Match BL-YYNNNN or BL-YYNNNN-suffix
        if (id && id.startsWith(prefix) && match) {
            const numPart = parseInt(match[1], 10); // Get the NNNN part
            if (!isNaN(numPart) && numPart > maxNum) {
                maxNum = numPart;
            }
        }
    });
    const nextNum = maxNum + 1;
    const nextNumPadded = nextNum.toString().padStart(4, '0'); // Pad with leading zeros to 4 digits
    const newBaseId = `${prefix}${nextNumPadded}`;
    console.log("Generated next backlog ID:", newBaseId, "based on max:", maxNum); // Debug log
    return newBaseId;
};
function Home() {
    _s();
    const [projects, setProjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]); // State for all projects
    const [selectedProjectId, setSelectedProjectId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Combined state for active main and sub tab. Format: "main/sub" or just "main"
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("dashboard");
    const [newProjectName, setNewProjectName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isNewProjectDialogOpen, setIsNewProjectDialogOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // Set default to false
    const [isAddMembersDialogOpen, setIsAddMembersDialogOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [newlyCreatedProjectId, setNewlyCreatedProjectId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // Track ID for Add Members dialog
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const [clientNow, setClientNow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // For client-side date comparison
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true); // Add loading state
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // State for delete project dialog
    const [projectToDeleteId, setProjectToDeleteId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // Track ID for deletion
    const [confirmProjectName, setConfirmProjectName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(''); // Input for delete confirmation
    // Get current date on client mount to avoid hydration issues
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            setClientNow(new Date());
        }
    }["Home.useEffect"], []);
    // Define default sub-tabs for each main tab
    const defaultSubTabs = {
        sprints: 'summary',
        backlog: 'management',
        analytics: 'charts',
        teams: 'members',
        settings: 'holidays'
    };
    // Update activeTab logic for main tabs
    const handleMainTabChange = (mainTabKey)=>{
        if (mainTabKey === 'dashboard') {
            setActiveTab(mainTabKey);
        } else {
            const defaultSub = defaultSubTabs[mainTabKey] || ''; // Fallback to empty string if no default
            setActiveTab(`${mainTabKey}/${defaultSub}`);
        }
    };
    // Get the active main tab key from the combined state
    const activeMainTab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Home.useMemo[activeMainTab]": ()=>activeTab.split('/')[0]
    }["Home.useMemo[activeMainTab]"], [
        activeTab
    ]);
    // Effect to load data from localStorage on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            console.log("Attempting to load data from localStorage...");
            setIsLoading(true);
            try {
                const savedData = localStorage.getItem('appData');
                const savedProjectId = localStorage.getItem('selectedProjectId');
                console.log("Retrieved 'appData' from localStorage:", savedData ? savedData.substring(0, 100) + '...' : 'null'); // Log truncated data or null
                console.log("Retrieved 'selectedProjectId' from localStorage:", savedProjectId);
                if (savedData) {
                    const parsedData = JSON.parse(savedData);
                    if (Array.isArray(parsedData)) {
                        // Validate and potentially migrate data here if needed
                        const validatedProjects = parsedData.map({
                            "Home.useEffect.validatedProjects": (project)=>({
                                    ...project,
                                    sprintData: project.sprintData ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialSprintData"],
                                    members: project.members ?? [],
                                    holidayCalendars: project.holidayCalendars ?? [],
                                    teams: project.teams ?? [],
                                    backlog: (project.backlog ?? []).map({
                                        "Home.useEffect.validatedProjects": (task)=>({
                                                ...task,
                                                priority: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["taskPriorities"].includes(task.priority) ? task.priority : 'Medium',
                                                // Ensure backlogId exists during validation
                                                backlogId: task.backlogId ?? `BL-LEGACY-${task.id}`,
                                                needsGrooming: task.needsGrooming ?? false,
                                                readyForSprint: task.readyForSprint ?? false,
                                                splitFromId: task.splitFromId,
                                                mergeEventId: task.mergeEventId
                                            })
                                    }["Home.useEffect.validatedProjects"]).sort({
                                        "Home.useEffect.validatedProjects": (a, b)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["taskPriorities"].indexOf(a.priority) - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["taskPriorities"].indexOf(b.priority) || (a.backlogId ?? '').localeCompare(b.backlogId ?? '')
                                    }["Home.useEffect.validatedProjects"]),
                                    sprintData: {
                                        ...project.sprintData,
                                        sprints: (project.sprintData?.sprints ?? []).sort({
                                            "Home.useEffect.validatedProjects": (a, b)=>a.sprintNumber - b.sprintNumber
                                        }["Home.useEffect.validatedProjects"])
                                    }
                                })
                        }["Home.useEffect.validatedProjects"]);
                        setProjects(validatedProjects);
                        console.log("Successfully loaded and validated project data from localStorage.");
                        // Restore selected project ID if it exists and is valid
                        if (savedProjectId && validatedProjects.some({
                            "Home.useEffect": (p)=>p.id === savedProjectId
                        }["Home.useEffect"])) {
                            setSelectedProjectId(savedProjectId);
                            console.log(`Restored selected project ID: ${savedProjectId}`);
                        } else {
                            // If saved ID is invalid or no projects, select the first project or null
                            setSelectedProjectId(validatedProjects.length > 0 ? validatedProjects[0].id : null);
                            console.log("Selected project ID not found or invalid, selecting first project or null.");
                            // Clean up invalid saved ID
                            if (savedProjectId) {
                                localStorage.removeItem('selectedProjectId');
                            }
                        }
                    } else {
                        throw new Error("Stored 'appData' is not an array.");
                    }
                } else {
                    console.log("No 'appData' found in localStorage. Initializing with empty state.");
                    setProjects([]); // Initialize with empty array if no data found
                    setSelectedProjectId(null);
                }
            } catch (error) {
                console.error("CRITICAL: Failed to parse or validate project data from localStorage. Error:", error.message, error.stack);
                toast({
                    variant: "destructive",
                    title: "Data Load Error",
                    description: "Could not load project data. Resetting to empty state. Please report this issue if it persists."
                });
                // Reset to a known good state
                setProjects([]);
                setSelectedProjectId(null);
                // Attempt to clear potentially corrupted data
                try {
                    localStorage.removeItem('appData');
                    localStorage.removeItem('selectedProjectId');
                } catch (clearError) {
                    console.error("Failed to clear corrupted data from localStorage:", clearError);
                }
            } finally{
                setIsLoading(false);
                console.log("Finished loading data attempt.");
            }
        }
    }["Home.useEffect"], [
        toast
    ]); // Rerun this effect only on mount (and if toast changes, which is unlikely)
    // Effect to save data to localStorage whenever projects change (now empty on first load)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            // Only run save logic after initial load is complete
            if (!isLoading) {
                console.log("Projects state changed, attempting to save to localStorage...");
                try {
                    const dataToSave = JSON.stringify(projects);
                    console.log("Stringified data to save:", dataToSave.substring(0, 500) + '...'); // Log truncated data
                    localStorage.setItem('appData', dataToSave);
                    console.log("Successfully saved project data to localStorage.");
                } catch (error) {
                    console.error("CRITICAL: Failed to save project data to localStorage. Error:", error.message, error.stack);
                    toast({
                        variant: "destructive",
                        title: "Save Error",
                        description: "Could not save project data locally. Data might be too large or storage is unavailable."
                    });
                }
            } else {
                console.log("Skipping save to localStorage during initial loading.");
            }
        }
    }["Home.useEffect"], [
        projects,
        isLoading,
        toast
    ]); // Add isLoading dependency
    // Effect to save the selected project ID
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            if (!isLoading) {
                try {
                    if (selectedProjectId) {
                        console.log(`Saving selected project ID to localStorage: ${selectedProjectId}`);
                        localStorage.setItem('selectedProjectId', selectedProjectId);
                    } else {
                        console.log("No project selected, removing selectedProjectId from localStorage.");
                        // Remove if no project is selected to avoid stale references
                        localStorage.removeItem('selectedProjectId');
                    }
                } catch (err) {
                    console.error("Error accessing localStorage for selectedProjectId:", err);
                    toast({
                        variant: "destructive",
                        title: "Storage Error",
                        description: "Could not save selected project."
                    });
                }
            } else {
                console.log("Skipping saving selected project ID during initial loading.");
            }
        }
    }["Home.useEffect"], [
        selectedProjectId,
        isLoading,
        toast
    ]);
    // Find the currently selected project object
    const selectedProject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Home.useMemo[selectedProject]": ()=>{
            const project = projects.find({
                "Home.useMemo[selectedProject]": (p)=>p.id === selectedProjectId
            }["Home.useMemo[selectedProject]"]) ?? null;
            console.log("Selected project determined:", project?.name ?? 'None');
            return project;
        }
    }["Home.useMemo[selectedProject]"], [
        projects,
        selectedProjectId
    ]);
    // Handler to save planning data AND potentially update sprint status (used by PlanningTab)
    const handleSavePlanningAndUpdateStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleSavePlanningAndUpdateStatus]": (sprintNumber, planningData, newStatus)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let currentProjectName = 'N/A';
            let statusUpdateMessage = '';
            let otherActiveSprintExists = false; // Moved declaration outside setProjects
            setProjects({
                "Home.useCallback[handleSavePlanningAndUpdateStatus]": (prevProjects)=>{
                    const projectIndex = prevProjects.findIndex({
                        "Home.useCallback[handleSavePlanningAndUpdateStatus].projectIndex": (p)=>p.id === selectedProjectId
                    }["Home.useCallback[handleSavePlanningAndUpdateStatus].projectIndex"]);
                    if (projectIndex === -1) return prevProjects; // Project not found
                    const currentProject = prevProjects[projectIndex];
                    currentProjectName = currentProject.name; // Capture name
                    const tempSprints = [
                        ...currentProject.sprintData.sprints ?? []
                    ]; // Handle null/undefined
                    // Check if starting this sprint would violate the single active sprint rule
                    if (newStatus === 'Active') {
                        otherActiveSprintExists = tempSprints.some({
                            "Home.useCallback[handleSavePlanningAndUpdateStatus]": (s)=>s.sprintNumber !== sprintNumber && s.status === 'Active'
                        }["Home.useCallback[handleSavePlanningAndUpdateStatus]"]);
                        if (otherActiveSprintExists) {
                            // This toast needs to be shown outside the setProjects call
                            return prevProjects; // Return the project unchanged
                        }
                    }
                    // Proceed with the update if the rule is not violated
                    const updatedSprints = tempSprints.map({
                        "Home.useCallback[handleSavePlanningAndUpdateStatus].updatedSprints": (s)=>{
                            if (s.sprintNumber === sprintNumber) {
                                let finalStatus = s.status;
                                // Only update status if newStatus is provided and different
                                if (newStatus && newStatus !== s.status) {
                                    finalStatus = newStatus;
                                    statusUpdateMessage = ` Sprint ${sprintNumber} status updated to ${newStatus}.`;
                                } else if (!newStatus && s.status === 'Active' && clientNow && s.endDate && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isValid$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValid"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseISO"])(s.endDate)) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isPast$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPast"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseISO"])(s.endDate))) {
                                // Auto-complete logic (currently commented out)
                                // console.warn(`Auto-completing sprint ${sprintNumber} based on end date.`);
                                // finalStatus = 'Completed';
                                // statusUpdateMessage = ` Sprint ${sprintNumber} auto-completed based on end date.`;
                                }
                                // Ensure task IDs are present and correctly typed before saving
                                const validatedPlanning = {
                                    ...planningData,
                                    newTasks: (planningData.newTasks || []).map({
                                        "Home.useCallback[handleSavePlanningAndUpdateStatus].updatedSprints": (task)=>({
                                                ...task,
                                                id: task.id || `task_save_new_${Date.now()}_${Math.random()}`,
                                                qaEstimatedTime: task.qaEstimatedTime ?? '2d',
                                                bufferTime: task.bufferTime ?? '1d',
                                                backlogId: task.backlogId ?? ''
                                            })
                                    }["Home.useCallback[handleSavePlanningAndUpdateStatus].updatedSprints"]),
                                    spilloverTasks: (planningData.spilloverTasks || []).map({
                                        "Home.useCallback[handleSavePlanningAndUpdateStatus].updatedSprints": (task)=>({
                                                ...task,
                                                id: task.id || `task_save_spill_${Date.now()}_${Math.random()}`,
                                                qaEstimatedTime: task.qaEstimatedTime ?? '2d',
                                                bufferTime: task.bufferTime ?? '1d',
                                                backlogId: task.backlogId ?? ''
                                            })
                                    }["Home.useCallback[handleSavePlanningAndUpdateStatus].updatedSprints"])
                                };
                                // Calculate committed points based on saved tasks
                                const committedPoints = [
                                    ...validatedPlanning.newTasks || [],
                                    ...validatedPlanning.spilloverTasks || []
                                ].reduce({
                                    "Home.useCallback[handleSavePlanningAndUpdateStatus].updatedSprints.committedPoints": (sum, task)=>sum + (Number(task.storyPoints) || 0)
                                }["Home.useCallback[handleSavePlanningAndUpdateStatus].updatedSprints.committedPoints"], 0);
                                return {
                                    ...s,
                                    planning: validatedPlanning,
                                    status: finalStatus,
                                    committedPoints: committedPoints
                                };
                            }
                            return s;
                        }
                    }["Home.useCallback[handleSavePlanningAndUpdateStatus].updatedSprints"]);
                    // Create a new project object with updated sprints
                    const updatedProject = {
                        ...currentProject,
                        sprintData: {
                            ...currentProject.sprintData ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialSprintData"],
                            sprints: updatedSprints
                        }
                    };
                    // Create a new projects array with the updated project
                    const updatedProjects = [
                        ...prevProjects
                    ];
                    updatedProjects[projectIndex] = updatedProject;
                    return updatedProjects;
                }
            }["Home.useCallback[handleSavePlanningAndUpdateStatus]"]);
            // Show toast *after* the setProjects update attempt
            if (otherActiveSprintExists) {
                // Show error toast if an active sprint already exists
                toast({
                    variant: "destructive",
                    title: "Active Sprint Limit",
                    description: `Only one sprint can be active at a time. Another sprint is already active.`
                });
            } else {
                // Show success toast if the update was successful
                toast({
                    title: "Success",
                    description: `Planning data saved for Sprint ${sprintNumber}.${statusUpdateMessage} in project '${currentProjectName}'`
                });
            }
        }
    }["Home.useCallback[handleSavePlanningAndUpdateStatus]"], [
        selectedProjectId,
        toast,
        clientNow
    ]);
    // Handler to create a new sprint and save its initial planning data (used by PlanningTab)
    const handleCreateAndPlanSprint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleCreateAndPlanSprint]": (sprintDetails, planningData)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let projectNameForToast = 'N/A';
            let projectWasUpdated = false;
            // Check sprint limits BEFORE attempting to create
            const currentSprints = projects.find({
                "Home.useCallback[handleCreateAndPlanSprint]": (p)=>p.id === selectedProjectId
            }["Home.useCallback[handleCreateAndPlanSprint]"])?.sprintData.sprints ?? [];
            const numPlanned = currentSprints.filter({
                "Home.useCallback[handleCreateAndPlanSprint]": (s)=>s.status === 'Planned'
            }["Home.useCallback[handleCreateAndPlanSprint]"]).length;
            const numActive = currentSprints.filter({
                "Home.useCallback[handleCreateAndPlanSprint]": (s)=>s.status === 'Active'
            }["Home.useCallback[handleCreateAndPlanSprint]"]).length;
            if (numPlanned >= 2 || numPlanned >= 1 && numActive >= 1) {
                toast({
                    variant: "destructive",
                    title: "Sprint Limit Reached",
                    description: "Cannot plan new sprint. Limit is 2 Planned or 1 Planned + 1 Active."
                });
                return; // Prevent creation
            }
            setProjects({
                "Home.useCallback[handleCreateAndPlanSprint]": (prevProjects)=>{
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleCreateAndPlanSprint].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                projectNameForToast = p.name;
                                if ((p.sprintData.sprints ?? []).some({
                                    "Home.useCallback[handleCreateAndPlanSprint].updatedProjects": (s)=>s.sprintNumber === sprintDetails.sprintNumber
                                }["Home.useCallback[handleCreateAndPlanSprint].updatedProjects"])) {
                                    console.error(`Sprint number ${sprintDetails.sprintNumber} already exists for project ${p.name}.`);
                                    // Error handled by returning original 'p'
                                    return p;
                                }
                                // Validate planning data before creating
                                const validatedPlanning = {
                                    ...planningData,
                                    newTasks: (planningData.newTasks || []).map({
                                        "Home.useCallback[handleCreateAndPlanSprint].updatedProjects": (task)=>({
                                                ...task,
                                                id: task.id || `task_create_new_${Date.now()}_${Math.random()}`,
                                                qaEstimatedTime: task.qaEstimatedTime ?? '2d',
                                                bufferTime: task.bufferTime ?? '1d',
                                                backlogId: task.backlogId ?? ''
                                            })
                                    }["Home.useCallback[handleCreateAndPlanSprint].updatedProjects"]),
                                    spilloverTasks: (planningData.spilloverTasks || []).map({
                                        "Home.useCallback[handleCreateAndPlanSprint].updatedProjects": (task)=>({
                                                ...task,
                                                id: task.id || `task_create_spill_${Date.now()}_${Math.random()}`,
                                                qaEstimatedTime: task.qaEstimatedTime ?? '2d',
                                                bufferTime: task.bufferTime ?? '1d',
                                                backlogId: task.backlogId ?? ''
                                            })
                                    }["Home.useCallback[handleCreateAndPlanSprint].updatedProjects"])
                                };
                                // Calculate committed points for the new sprint
                                const committedPoints = [
                                    ...validatedPlanning.newTasks || [],
                                    ...validatedPlanning.spilloverTasks || []
                                ].reduce({
                                    "Home.useCallback[handleCreateAndPlanSprint].updatedProjects.committedPoints": (sum, task)=>sum + (Number(task.storyPoints) || 0)
                                }["Home.useCallback[handleCreateAndPlanSprint].updatedProjects.committedPoints"], 0);
                                const newSprint = {
                                    ...sprintDetails,
                                    committedPoints: committedPoints,
                                    completedPoints: 0,
                                    status: 'Planned',
                                    details: [],
                                    planning: validatedPlanning
                                };
                                const updatedSprints = [
                                    ...p.sprintData.sprints ?? [],
                                    newSprint
                                ]; // Handle null/undefined
                                updatedSprints.sort({
                                    "Home.useCallback[handleCreateAndPlanSprint].updatedProjects": (a, b)=>a.sprintNumber - b.sprintNumber
                                }["Home.useCallback[handleCreateAndPlanSprint].updatedProjects"]);
                                projectWasUpdated = true; // Mark that an update occurred
                                return {
                                    ...p,
                                    sprintData: {
                                        ...p.sprintData ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialSprintData"],
                                        sprints: updatedSprints,
                                        daysInSprint: Math.max(p.sprintData?.daysInSprint || 0, newSprint.totalDays)
                                    }
                                };
                            }
                            return p;
                        }
                    }["Home.useCallback[handleCreateAndPlanSprint].updatedProjects"]);
                    // If no update happened (e.g., sprint number existed), return the previous state
                    if (!projectWasUpdated) {
                        // Using setTimeout to ensure toast doesn't interfere with rendering updates
                        setTimeout({
                            "Home.useCallback[handleCreateAndPlanSprint]": ()=>{
                                toast({
                                    variant: "destructive",
                                    title: "Error",
                                    description: `Sprint number ${sprintDetails.sprintNumber} already exists in project '${projectNameForToast}'.`
                                });
                            }
                        }["Home.useCallback[handleCreateAndPlanSprint]"], 0);
                        return prevProjects;
                    }
                    // Return the updated projects array
                    return updatedProjects;
                }
            }["Home.useCallback[handleCreateAndPlanSprint]"]);
            // Show toast *after* setProjects has potentially completed its update cycle
            if (projectWasUpdated) {
                // Using setTimeout to ensure toast doesn't interfere with rendering updates
                setTimeout({
                    "Home.useCallback[handleCreateAndPlanSprint]": ()=>{
                        toast({
                            title: "Success",
                            description: `Sprint ${sprintDetails.sprintNumber} created and planned for project '${projectNameForToast}'.`
                        });
                    }
                }["Home.useCallback[handleCreateAndPlanSprint]"], 50); // Increased timeout
            }
        }
    }["Home.useCallback[handleCreateAndPlanSprint]"], [
        selectedProjectId,
        toast,
        projects
    ]); // Added projects dependency for limit check
    // Handler to complete a sprint
    const handleCompleteSprint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleCompleteSprint]": (sprintNumber)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let currentProjectName = 'N/A';
            setProjects({
                "Home.useCallback[handleCompleteSprint]": (prevProjects)=>{
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleCompleteSprint].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                currentProjectName = p.name;
                                const updatedSprints = p.sprintData.sprints.map({
                                    "Home.useCallback[handleCompleteSprint].updatedProjects.updatedSprints": (s)=>{
                                        if (s.sprintNumber === sprintNumber && s.status === 'Active') {
                                            // Calculate completed points based on 'Done' tasks in the current planning state
                                            const completedPoints = [
                                                ...s.planning?.newTasks || [],
                                                ...s.planning?.spilloverTasks || []
                                            ].filter({
                                                "Home.useCallback[handleCompleteSprint].updatedProjects.updatedSprints.completedPoints": (task)=>task.status === 'Done'
                                            }["Home.useCallback[handleCompleteSprint].updatedProjects.updatedSprints.completedPoints"]).reduce({
                                                "Home.useCallback[handleCompleteSprint].updatedProjects.updatedSprints.completedPoints": (sum, task)=>sum + (Number(task.storyPoints) || 0)
                                            }["Home.useCallback[handleCompleteSprint].updatedProjects.updatedSprints.completedPoints"], 0);
                                            // Move unfinished tasks back to backlog? (Optional - requires more complex logic)
                                            // For now, just update status and points
                                            return {
                                                ...s,
                                                status: 'Completed',
                                                completedPoints: completedPoints
                                            };
                                        }
                                        return s;
                                    }
                                }["Home.useCallback[handleCompleteSprint].updatedProjects.updatedSprints"]);
                                return {
                                    ...p,
                                    sprintData: {
                                        ...p.sprintData,
                                        sprints: updatedSprints
                                    }
                                };
                            }
                            return p;
                        }
                    }["Home.useCallback[handleCompleteSprint].updatedProjects"]);
                    return updatedProjects;
                }
            }["Home.useCallback[handleCompleteSprint]"]);
            toast({
                title: "Success",
                description: `Sprint ${sprintNumber} marked as Completed in project '${currentProjectName}'.`
            });
            // Optionally switch tab or select next planned sprint
            setActiveTab('sprints/summary');
        }
    }["Home.useCallback[handleCompleteSprint]"], [
        selectedProjectId,
        toast,
        setActiveTab
    ]);
    // Handler to save members for the *selected* project
    const handleSaveMembers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleSaveMembers]": (updatedMembers)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let currentProjectName = 'N/A';
            setProjects({
                "Home.useCallback[handleSaveMembers]": (prevProjects)=>{
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleSaveMembers].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                currentProjectName = p.name; // Capture name
                                return {
                                    ...p,
                                    members: updatedMembers
                                };
                            }
                            return p;
                        }
                    }["Home.useCallback[handleSaveMembers].updatedProjects"]);
                    return updatedProjects;
                }
            }["Home.useCallback[handleSaveMembers]"]);
            toast({
                title: "Success",
                description: `Members updated for project '${currentProjectName}'.`
            });
        }
    }["Home.useCallback[handleSaveMembers]"], [
        selectedProjectId,
        toast
    ]);
    // Handler to save holiday calendars for the *selected* project
    const handleSaveHolidayCalendars = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleSaveHolidayCalendars]": (updatedCalendars)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let currentProjectName = 'N/A';
            let membersToUpdate = [];
            setProjects({
                "Home.useCallback[handleSaveHolidayCalendars]": (prevProjects)=>{
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleSaveHolidayCalendars].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                currentProjectName = p.name; // Capture name
                                // Keep track of members whose calendars might change
                                membersToUpdate = (p.members || []).map({
                                    "Home.useCallback[handleSaveHolidayCalendars].updatedProjects": (member)=>{
                                        if (member.holidayCalendarId && !updatedCalendars.some({
                                            "Home.useCallback[handleSaveHolidayCalendars].updatedProjects": (cal)=>cal.id === member.holidayCalendarId
                                        }["Home.useCallback[handleSaveHolidayCalendars].updatedProjects"])) {
                                            return {
                                                ...member,
                                                holidayCalendarId: null
                                            }; // Mark for update
                                        }
                                        return member;
                                    }
                                }["Home.useCallback[handleSaveHolidayCalendars].updatedProjects"]).filter({
                                    "Home.useCallback[handleSaveHolidayCalendars].updatedProjects": (m, index)=>m.holidayCalendarId !== (p.members || [])[index].holidayCalendarId
                                }["Home.useCallback[handleSaveHolidayCalendars].updatedProjects"]); // Only keep those that changed
                                const updatedMembers = (p.members || []).map({
                                    "Home.useCallback[handleSaveHolidayCalendars].updatedProjects.updatedMembers": (member)=>({
                                            ...member,
                                            holidayCalendarId: member.holidayCalendarId && updatedCalendars.some({
                                                "Home.useCallback[handleSaveHolidayCalendars].updatedProjects.updatedMembers": (cal)=>cal.id === member.holidayCalendarId
                                            }["Home.useCallback[handleSaveHolidayCalendars].updatedProjects.updatedMembers"]) ? member.holidayCalendarId : null
                                        })
                                }["Home.useCallback[handleSaveHolidayCalendars].updatedProjects.updatedMembers"]);
                                return {
                                    ...p,
                                    holidayCalendars: updatedCalendars,
                                    members: updatedMembers
                                };
                            }
                            return p;
                        }
                    }["Home.useCallback[handleSaveHolidayCalendars].updatedProjects"]);
                    return updatedProjects;
                }
            }["Home.useCallback[handleSaveHolidayCalendars]"]);
            // Show toasts *after* the state update
            setTimeout({
                "Home.useCallback[handleSaveHolidayCalendars]": ()=>{
                    toast({
                        title: "Success",
                        description: `Holiday calendars updated for project '${currentProjectName}'.`
                    });
                    membersToUpdate.forEach({
                        "Home.useCallback[handleSaveHolidayCalendars]": (member)=>{
                            toast({
                                variant: "warning",
                                title: "Calendar Unassigned",
                                description: `Holiday calendar assigned to ${member.name} was deleted or is no longer available.`
                            });
                        }
                    }["Home.useCallback[handleSaveHolidayCalendars]"]);
                }
            }["Home.useCallback[handleSaveHolidayCalendars]"], 0);
        }
    }["Home.useCallback[handleSaveHolidayCalendars]"], [
        selectedProjectId,
        toast
    ]);
    // Handler to save teams for the *selected* project
    const handleSaveTeams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleSaveTeams]": (updatedTeams)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let currentProjectName = 'N/A';
            setProjects({
                "Home.useCallback[handleSaveTeams]": (prevProjects)=>{
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleSaveTeams].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                currentProjectName = p.name; // Capture name
                                // Optionally, add validation here to ensure team members and leads still exist
                                const validTeams = updatedTeams.map({
                                    "Home.useCallback[handleSaveTeams].updatedProjects.validTeams": (team)=>{
                                        const validMembers = team.members.filter({
                                            "Home.useCallback[handleSaveTeams].updatedProjects.validTeams.validMembers": (tm)=>(p.members || []).some({
                                                    "Home.useCallback[handleSaveTeams].updatedProjects.validTeams.validMembers": (m)=>m.id === tm.memberId
                                                }["Home.useCallback[handleSaveTeams].updatedProjects.validTeams.validMembers"])
                                        }["Home.useCallback[handleSaveTeams].updatedProjects.validTeams.validMembers"]);
                                        let validLead = team.leadMemberId;
                                        if (validLead && !(p.members || []).some({
                                            "Home.useCallback[handleSaveTeams].updatedProjects.validTeams": (m)=>m.id === validLead
                                        }["Home.useCallback[handleSaveTeams].updatedProjects.validTeams"])) {
                                            console.warn(`Lead member ID ${validLead} for team ${team.name} not found. Resetting.`);
                                            validLead = null;
                                        }
                                        return {
                                            ...team,
                                            members: validMembers,
                                            leadMemberId: validLead
                                        };
                                    }
                                }["Home.useCallback[handleSaveTeams].updatedProjects.validTeams"]);
                                return {
                                    ...p,
                                    teams: validTeams
                                };
                            }
                            return p;
                        }
                    }["Home.useCallback[handleSaveTeams].updatedProjects"]);
                    return updatedProjects;
                }
            }["Home.useCallback[handleSaveTeams]"]);
            toast({
                title: "Success",
                description: `Teams updated for project '${currentProjectName}'.`
            });
        }
    }["Home.useCallback[handleSaveTeams]"], [
        selectedProjectId,
        toast
    ]);
    // Handler to save NEW backlog items (from the new items table)
    const handleSaveNewBacklogItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleSaveNewBacklogItems]": (newItems)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let currentProjectName = 'N/A';
            setProjects({
                "Home.useCallback[handleSaveNewBacklogItems]": (prevProjects)=>{
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleSaveNewBacklogItems].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                currentProjectName = p.name;
                                const existingBacklog = p.backlog ?? [];
                                // Assign persistent IDs to new items before adding
                                const itemsWithIds = newItems.map({
                                    "Home.useCallback[handleSaveNewBacklogItems].updatedProjects.itemsWithIds": (item, index)=>({
                                            ...item,
                                            id: `backlog_${p.id}_${Date.now()}_${index}`
                                        })
                                }["Home.useCallback[handleSaveNewBacklogItems].updatedProjects.itemsWithIds"]);
                                const updatedBacklog = [
                                    ...existingBacklog,
                                    ...itemsWithIds
                                ];
                                // Re-sort the entire backlog after adding
                                updatedBacklog.sort({
                                    "Home.useCallback[handleSaveNewBacklogItems].updatedProjects": (a, b)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["taskPriorities"].indexOf(a.priority) - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["taskPriorities"].indexOf(b.priority) || (a.backlogId ?? '').localeCompare(b.backlogId ?? '')
                                }["Home.useCallback[handleSaveNewBacklogItems].updatedProjects"]);
                                return {
                                    ...p,
                                    backlog: updatedBacklog
                                };
                            }
                            return p;
                        }
                    }["Home.useCallback[handleSaveNewBacklogItems].updatedProjects"]);
                    return updatedProjects;
                }
            }["Home.useCallback[handleSaveNewBacklogItems]"]);
        // No separate toast here, handled in BacklogTab's save function
        }
    }["Home.useCallback[handleSaveNewBacklogItems]"], [
        selectedProjectId,
        toast
    ]);
    // Handler to update a specific SAVED backlog item
    const handleUpdateSavedBacklogItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleUpdateSavedBacklogItem]": (updatedItem)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            setProjects({
                "Home.useCallback[handleUpdateSavedBacklogItem]": (prevProjects)=>prevProjects.map({
                        "Home.useCallback[handleUpdateSavedBacklogItem]": (p)=>p.id === selectedProjectId ? {
                                ...p,
                                backlog: (p.backlog ?? []).map({
                                    "Home.useCallback[handleUpdateSavedBacklogItem]": (item)=>item.id === updatedItem.id ? updatedItem : item
                                }["Home.useCallback[handleUpdateSavedBacklogItem]"])
                            } : p
                    }["Home.useCallback[handleUpdateSavedBacklogItem]"])
            }["Home.useCallback[handleUpdateSavedBacklogItem]"]);
        // Optional: Add a success toast here if needed
        }
    }["Home.useCallback[handleUpdateSavedBacklogItem]"], [
        selectedProjectId,
        toast
    ]);
    // Handler to delete a specific SAVED backlog item
    const handleDeleteSavedBacklogItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleDeleteSavedBacklogItem]": (itemId)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            // TODO: Add confirmation dialog here before deleting
            setProjects({
                "Home.useCallback[handleDeleteSavedBacklogItem]": (prevProjects)=>prevProjects.map({
                        "Home.useCallback[handleDeleteSavedBacklogItem]": (p)=>p.id === selectedProjectId ? {
                                ...p,
                                backlog: (p.backlog ?? []).filter({
                                    "Home.useCallback[handleDeleteSavedBacklogItem]": (item)=>item.id !== itemId
                                }["Home.useCallback[handleDeleteSavedBacklogItem]"])
                            } : p
                    }["Home.useCallback[handleDeleteSavedBacklogItem]"])
            }["Home.useCallback[handleDeleteSavedBacklogItem]"]);
            toast({
                title: "Backlog Item Deleted",
                description: "The item has been removed from the backlog."
            });
        }
    }["Home.useCallback[handleDeleteSavedBacklogItem]"], [
        selectedProjectId,
        toast
    ]);
    // Handler to move a backlog item to a sprint
    const handleMoveToSprint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleMoveToSprint]": (backlogItemId, targetSprintNumber)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let currentProjectName = 'N/A';
            let movedItemDetails = null;
            setProjects({
                "Home.useCallback[handleMoveToSprint]": (prevProjects)=>{
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleMoveToSprint].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                currentProjectName = p.name; // Capture name
                                const backlogItemIndex = (p.backlog ?? []).findIndex({
                                    "Home.useCallback[handleMoveToSprint].updatedProjects.backlogItemIndex": (item)=>item.id === backlogItemId
                                }["Home.useCallback[handleMoveToSprint].updatedProjects.backlogItemIndex"]);
                                if (backlogItemIndex === -1) {
                                    console.error("Backlog item not found:", backlogItemId);
                                    // Don't show toast here, maybe already removed?
                                    return p; // Return unchanged project
                                }
                                const backlogItem = p.backlog[backlogItemIndex];
                                movedItemDetails = `${backlogItem.backlogId} (${backlogItem.title || 'No Title'})`; // For toast message
                                const targetSprintIndex = (p.sprintData.sprints ?? []).findIndex({
                                    "Home.useCallback[handleMoveToSprint].updatedProjects.targetSprintIndex": (s)=>s.sprintNumber === targetSprintNumber
                                }["Home.useCallback[handleMoveToSprint].updatedProjects.targetSprintIndex"]);
                                if (targetSprintIndex === -1) {
                                    console.error("Target sprint not found:", targetSprintNumber);
                                    toast({
                                        variant: "destructive",
                                        title: "Error",
                                        description: "Target sprint not found."
                                    });
                                    return p; // Return unchanged project
                                }
                                // Create the task for the sprint
                                const sprintTask = {
                                    ...backlogItem,
                                    id: `sprint_task_${Date.now()}_${Math.random()}`,
                                    status: 'To Do',
                                    startDate: undefined,
                                    devEstimatedTime: backlogItem.devEstimatedTime ?? '',
                                    qaEstimatedTime: backlogItem.qaEstimatedTime ?? '2d',
                                    bufferTime: backlogItem.bufferTime ?? '1d',
                                    // Carry over other relevant fields if needed (assignee, reviewer, etc.)
                                    assignee: backlogItem.assignee,
                                    reviewer: backlogItem.reviewer,
                                    // Clear backlog-specific fields that shouldn't be in sprint context
                                    // taskType: undefined, // Keep taskType for history? Decide later.
                                    // createdDate: undefined, // Keep createdDate? Decide later.
                                    initiator: backlogItem.initiator,
                                    movedToSprint: undefined,
                                    historyStatus: undefined,
                                    needsGrooming: undefined,
                                    readyForSprint: undefined,
                                    backlogId: backlogItem.backlogId ?? ''
                                };
                                // Instead of removing, update the item in backlog to mark it as moved
                                const updatedBacklog = p.backlog.map({
                                    "Home.useCallback[handleMoveToSprint].updatedProjects.updatedBacklog": (item, index)=>{
                                        if (index === backlogItemIndex) {
                                            return {
                                                ...item,
                                                movedToSprint: targetSprintNumber,
                                                historyStatus: 'Move'
                                            }; // Set history status to 'Move'
                                        }
                                        return item;
                                    }
                                }["Home.useCallback[handleMoveToSprint].updatedProjects.updatedBacklog"]);
                                // Add item to the target sprint's newTasks
                                const updatedSprints = [
                                    ...p.sprintData.sprints
                                ];
                                const targetSprint = updatedSprints[targetSprintIndex];
                                const updatedPlanning = {
                                    ...targetSprint.planning ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialSprintPlanning"],
                                    newTasks: [
                                        ...targetSprint.planning?.newTasks ?? [],
                                        sprintTask
                                    ]
                                };
                                updatedSprints[targetSprintIndex] = {
                                    ...targetSprint,
                                    planning: updatedPlanning
                                };
                                return {
                                    ...p,
                                    backlog: updatedBacklog,
                                    sprintData: {
                                        ...p.sprintData,
                                        sprints: updatedSprints
                                    }
                                };
                            }
                            return p;
                        }
                    }["Home.useCallback[handleMoveToSprint].updatedProjects"]);
                    return updatedProjects;
                }
            }["Home.useCallback[handleMoveToSprint]"]);
            if (movedItemDetails) {
                toast({
                    title: "Item Moved",
                    description: `Backlog item '${movedItemDetails}' moved to Sprint ${targetSprintNumber}. Marked in backlog.`
                });
            }
        }
    }["Home.useCallback[handleMoveToSprint]"], [
        selectedProjectId,
        toast
    ]);
    // Handler to revert a task from sprint planning back to the backlog
    const handleRevertTaskToBacklog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleRevertTaskToBacklog]": (sprintNumber, taskId, taskBacklogId)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let revertedTaskDetails = null;
            let updatePerformed = false; // Track if an update actually happened
            // Use setTimeout to ensure toast is shown after state update attempt
            const showToast = {
                "Home.useCallback[handleRevertTaskToBacklog].showToast": (options)=>setTimeout({
                        "Home.useCallback[handleRevertTaskToBacklog].showToast": ()=>toast(options)
                    }["Home.useCallback[handleRevertTaskToBacklog].showToast"], 0)
            }["Home.useCallback[handleRevertTaskToBacklog].showToast"];
            setProjects({
                "Home.useCallback[handleRevertTaskToBacklog]": (prevProjects)=>{
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleRevertTaskToBacklog].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                let foundAndRemoved = false;
                                let taskToRemoveDetails = {};
                                let originalProject = p; // Keep reference to original project state for toast
                                // Find the task in the specified sprint's planning.newTasks
                                let targetSprintIndex = p.sprintData.sprints.findIndex({
                                    "Home.useCallback[handleRevertTaskToBacklog].updatedProjects.targetSprintIndex": (s)=>s.sprintNumber === sprintNumber
                                }["Home.useCallback[handleRevertTaskToBacklog].updatedProjects.targetSprintIndex"]);
                                if (targetSprintIndex === -1) {
                                    console.warn(`Sprint ${sprintNumber} not found.`);
                                    showToast({
                                        variant: "warning",
                                        title: "Sprint Not Found",
                                        description: `Could not find Sprint ${sprintNumber}.`
                                    });
                                    return originalProject;
                                }
                                let targetSprint = p.sprintData.sprints[targetSprintIndex];
                                let updatedNewTasks = [
                                    ...targetSprint.planning?.newTasks || []
                                ];
                                let taskIndex = updatedNewTasks.findIndex({
                                    "Home.useCallback[handleRevertTaskToBacklog].updatedProjects.taskIndex": (t)=>t.id === taskId
                                }["Home.useCallback[handleRevertTaskToBacklog].updatedProjects.taskIndex"]);
                                if (taskIndex !== -1) {
                                    const taskToRemove = updatedNewTasks[taskIndex];
                                    taskToRemoveDetails = {
                                        ...taskToRemove
                                    }; // Capture details before removing
                                    // Use backlog ID if available, otherwise ticket number
                                    revertedTaskDetails = `${taskToRemove.backlogId || taskToRemove.ticketNumber} (${taskToRemove.title || 'No Title'})`;
                                    foundAndRemoved = true;
                                    updatedNewTasks.splice(taskIndex, 1); // Remove the task
                                } else {
                                    console.warn(`Task ID ${taskId} not found in Sprint ${sprintNumber} new tasks.`);
                                    showToast({
                                        variant: "warning",
                                        title: "Task Not Found",
                                        description: `Could not find task ID ${taskId} in Sprint ${sprintNumber} planning.`
                                    });
                                    return originalProject; // Return original project state
                                }
                                // If the task wasn't found in the sprint, no need to update backlog (handled above)
                                // Update the sprint with the modified tasks
                                const updatedSprints = [
                                    ...p.sprintData.sprints
                                ];
                                updatedSprints[targetSprintIndex] = {
                                    ...targetSprint,
                                    planning: {
                                        ...targetSprint.planning || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialSprintPlanning"],
                                        newTasks: updatedNewTasks
                                    }
                                };
                                // Find the corresponding item in the backlog and reset its 'movedToSprint' status
                                const updatedBacklog = (p.backlog || []).map({
                                    "Home.useCallback[handleRevertTaskToBacklog].updatedProjects.updatedBacklog": (item)=>{
                                        // Match primarily using taskBacklogId if available, otherwise try matching by ticketNumber if backlogId is missing
                                        const isMatch = taskBacklogId ? item.backlogId === taskBacklogId : item.ticketNumber === taskToRemoveDetails.ticketNumber;
                                        if (isMatch && item.movedToSprint === sprintNumber && item.historyStatus === 'Move') {
                                            updatePerformed = true; // Mark that we found and updated the backlog item
                                            return {
                                                ...item,
                                                movedToSprint: undefined,
                                                historyStatus: undefined
                                            }; // Reset movedToSprint and historyStatus
                                        }
                                        return item;
                                    }
                                }["Home.useCallback[handleRevertTaskToBacklog].updatedProjects.updatedBacklog"]);
                                // If the backlog item was not found to be updated (e.g., it was manually deleted from backlog), show a warning
                                if (!updatePerformed) {
                                    console.warn(`Could not find corresponding backlog item for task ${revertedTaskDetails} (Backlog ID: ${taskBacklogId}) that was marked as moved to sprint ${sprintNumber}. Task removed from sprint only.`);
                                    showToast({
                                        variant: "warning",
                                        title: "Task Removed from Sprint",
                                        description: `Task '${revertedTaskDetails}' removed from Sprint ${sprintNumber}, but its corresponding backlog item couldn't be updated (may have been deleted or modified).`
                                    });
                                } else {
                                    showToast({
                                        title: "Task Reverted",
                                        description: `Task '${revertedTaskDetails}' removed from Sprint ${sprintNumber} and returned to backlog.`
                                    });
                                }
                                return {
                                    ...p,
                                    backlog: updatedBacklog,
                                    sprintData: {
                                        ...p.sprintData,
                                        sprints: updatedSprints
                                    }
                                };
                            }
                            return p;
                        }
                    }["Home.useCallback[handleRevertTaskToBacklog].updatedProjects"]);
                    return updatedProjects;
                }
            }["Home.useCallback[handleRevertTaskToBacklog]"]);
        }
    }["Home.useCallback[handleRevertTaskToBacklog]"], [
        selectedProjectId,
        toast,
        setProjects
    ]); // Include setProjects
    // Handler to split a backlog item
    const handleSplitBacklogItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleSplitBacklogItem]": (originalTaskId, splitTasks)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let originalTaskDetails = null;
            let newIds = [];
            setProjects({
                "Home.useCallback[handleSplitBacklogItem]": (prevProjects)=>{
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleSplitBacklogItem].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                const originalBacklogIndex = (p.backlog ?? []).findIndex({
                                    "Home.useCallback[handleSplitBacklogItem].updatedProjects.originalBacklogIndex": (item)=>item.id === originalTaskId
                                }["Home.useCallback[handleSplitBacklogItem].updatedProjects.originalBacklogIndex"]);
                                if (originalBacklogIndex === -1) {
                                    console.error("Original backlog item not found for splitting:", originalTaskId);
                                    toast({
                                        variant: "destructive",
                                        title: "Error",
                                        description: "Original item not found."
                                    });
                                    return p;
                                }
                                const originalItem = p.backlog[originalBacklogIndex];
                                originalTaskDetails = `${originalItem.backlogId} (${originalItem.title || 'No Title'})`;
                                // 1. Mark the original item with 'Split' status in history
                                const markedOriginalItem = {
                                    ...originalItem,
                                    historyStatus: 'Split',
                                    movedToSprint: undefined,
                                    splitFromId: undefined
                                };
                                // 2. Prepare new split tasks with unique IDs and backlog IDs
                                const allItemsForIdGen = [
                                    ...p.backlog || [],
                                    ...splitTasks
                                ]; // Include potential new tasks for ID uniqueness check
                                const newSplitTasksWithIds = splitTasks.map({
                                    "Home.useCallback[handleSplitBacklogItem].updatedProjects.newSplitTasksWithIds": (task, index)=>{
                                        // Split results now get their own unique, standard IDs
                                        const suffix = String.fromCharCode(97 + index); // 'a', 'b', 'c'...
                                        const newSplitBacklogId = `${originalItem.backlogId}-${suffix}`;
                                        return {
                                            ...task,
                                            id: `split_${originalTaskId}_${newSplitBacklogId}_${Date.now()}`,
                                            backlogId: newSplitBacklogId,
                                            ticketNumber: newSplitBacklogId,
                                            needsGrooming: true,
                                            readyForSprint: false,
                                            splitFromId: originalItem.id
                                        };
                                    }
                                }["Home.useCallback[handleSplitBacklogItem].updatedProjects.newSplitTasksWithIds"]);
                                newIds = newSplitTasksWithIds.map({
                                    "Home.useCallback[handleSplitBacklogItem].updatedProjects": (t)=>t.backlogId || t.id
                                }["Home.useCallback[handleSplitBacklogItem].updatedProjects"]); // Store new IDs for toast
                                // 3. Update the backlog array: Replace original with historical, add new splits
                                const updatedBacklog = [
                                    ...p.backlog?.slice(0, originalBacklogIndex) ?? [],
                                    markedOriginalItem,
                                    ...newSplitTasksWithIds,
                                    ...p.backlog?.slice(originalBacklogIndex + 1) ?? []
                                ];
                                return {
                                    ...p,
                                    backlog: updatedBacklog.sort({
                                        "Home.useCallback[handleSplitBacklogItem].updatedProjects": (a, b)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["taskPriorities"].indexOf(a.priority) - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["taskPriorities"].indexOf(b.priority) || (a.backlogId ?? '').localeCompare(b.backlogId ?? '')
                                    }["Home.useCallback[handleSplitBacklogItem].updatedProjects"])
                                };
                            }
                            return p;
                        }
                    }["Home.useCallback[handleSplitBacklogItem].updatedProjects"]);
                    return updatedProjects;
                }
            }["Home.useCallback[handleSplitBacklogItem]"]);
            if (originalTaskDetails) {
                toast({
                    title: "Item Split",
                    description: `Backlog item '${originalTaskDetails}' marked as Split. New items added: ${newIds.join(', ')}.`,
                    duration: 5000
                });
            }
        }
    }["Home.useCallback[handleSplitBacklogItem]"], [
        selectedProjectId,
        toast
    ]); // Removed generateNextBacklogId dependency
    // Handler to merge backlog items
    const handleMergeBacklogItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleMergeBacklogItems]": (taskIdsToMerge, mergedTask)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            if (taskIdsToMerge.length < 2) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "At least two items must be selected for merging."
                });
                return;
            }
            const mergeEventId = `merge_${Date.now()}`; // Generate a unique ID for this merge event
            let mergedItemDetails = [];
            setProjects({
                "Home.useCallback[handleMergeBacklogItems]": (prevProjects)=>{
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleMergeBacklogItems].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                let updatedBacklog = [
                                    ...p.backlog ?? []
                                ];
                                const itemsToMarkHistorical = [];
                                let firstOriginalBacklogId = undefined;
                                // Mark original items as merged
                                updatedBacklog = updatedBacklog.map({
                                    "Home.useCallback[handleMergeBacklogItems].updatedProjects": (item)=>{
                                        if (taskIdsToMerge.includes(item.id)) {
                                            if (!firstOriginalBacklogId) {
                                                firstOriginalBacklogId = item.backlogId; // Capture the first original ID for naming convention
                                            }
                                            mergedItemDetails.push(`${item.backlogId} (${item.title || 'No Title'})`);
                                            itemsToMarkHistorical.push({
                                                ...item,
                                                historyStatus: 'Merge',
                                                movedToSprint: undefined,
                                                mergeEventId: mergeEventId
                                            });
                                            return null; // Mark for removal from active backlog later
                                        }
                                        return item;
                                    }
                                }["Home.useCallback[handleMergeBacklogItems].updatedProjects"]).filter({
                                    "Home.useCallback[handleMergeBacklogItems].updatedProjects": (item)=>item !== null
                                }["Home.useCallback[handleMergeBacklogItems].updatedProjects"]); // Remove the original items from active view
                                // Generate the new merged backlog ID
                                const newMergedBacklogId = `${firstOriginalBacklogId || 'merged'}-m`; // Use first original ID + '-m'
                                const newMergedTaskWithId = {
                                    ...mergedTask,
                                    id: `merged_${Date.now()}_${Math.random()}`,
                                    backlogId: newMergedBacklogId,
                                    ticketNumber: newMergedBacklogId,
                                    needsGrooming: true,
                                    readyForSprint: false,
                                    mergeEventId: mergeEventId
                                };
                                // Combine active backlog, new merged task, and historical items
                                const finalBacklog = [
                                    ...updatedBacklog,
                                    newMergedTaskWithId,
                                    ...itemsToMarkHistorical
                                ];
                                return {
                                    ...p,
                                    backlog: finalBacklog.sort({
                                        "Home.useCallback[handleMergeBacklogItems].updatedProjects": (a, b)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["taskPriorities"].indexOf(a.priority) - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["taskPriorities"].indexOf(b.priority) || (a.backlogId ?? '').localeCompare(b.backlogId ?? '')
                                    }["Home.useCallback[handleMergeBacklogItems].updatedProjects"])
                                };
                            }
                            return p;
                        }
                    }["Home.useCallback[handleMergeBacklogItems].updatedProjects"]);
                    return updatedProjects;
                }
            }["Home.useCallback[handleMergeBacklogItems]"]);
            toast({
                title: "Items Merged",
                description: `Items [${mergedItemDetails.join(', ')}] marked as Merged. New item '${mergedTask.title}' created.`,
                duration: 5000
            });
        }
    }["Home.useCallback[handleMergeBacklogItems]"], [
        selectedProjectId,
        toast
    ]); // Removed generateNextBacklogId dependency
    // Handler to undo a backlog action (Split/Merge)
    const handleUndoBacklogAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleUndoBacklogAction]": (taskId)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let undoneActionType;
            let undoneItemDetails = null;
            let restoredItemIds = [];
            let removedItemIds = [];
            let actionSuccess = false; // Track if the undo logic successfully modified state
            // Defer toast to avoid render interference
            const showToast = {
                "Home.useCallback[handleUndoBacklogAction].showToast": (options)=>setTimeout({
                        "Home.useCallback[handleUndoBacklogAction].showToast": ()=>toast(options)
                    }["Home.useCallback[handleUndoBacklogAction].showToast"], 50)
            }["Home.useCallback[handleUndoBacklogAction].showToast"];
            setProjects({
                "Home.useCallback[handleUndoBacklogAction]": (prevProjects)=>{
                    let projectUpdated = false;
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                let updatedBacklog = [
                                    ...p.backlog || []
                                ];
                                const triggerItem = updatedBacklog.find({
                                    "Home.useCallback[handleUndoBacklogAction].updatedProjects.triggerItem": (item)=>item.id === taskId
                                }["Home.useCallback[handleUndoBacklogAction].updatedProjects.triggerItem"]);
                                if (!triggerItem) {
                                    console.error("Undo Trigger item not found:", taskId);
                                    showToast({
                                        variant: "destructive",
                                        title: "Error",
                                        description: "Cannot perform undo: Item not found."
                                    });
                                    return p;
                                }
                                // Enhanced logging for debugging
                                console.log("Attempting to undo action for item:", triggerItem);
                                let originalItemToRestore;
                                let itemsToRemove = [];
                                let itemsToRestore = [];
                                let mergeEventId;
                                // Determine action and related items based on the *trigger item*
                                if (triggerItem.historyStatus === 'Split') {
                                    undoneActionType = 'Split';
                                    originalItemToRestore = triggerItem; // This is the item to restore
                                    itemsToRemove = updatedBacklog.filter({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (item)=>item.splitFromId === originalItemToRestore.id
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]); // Find results by splitFromId
                                } else if (triggerItem.historyStatus === 'Merge') {
                                    undoneActionType = 'Merge';
                                    mergeEventId = triggerItem.mergeEventId;
                                    if (!mergeEventId) {
                                        console.error("Cannot undo merge: Missing mergeEventId on historical item", taskId);
                                        showToast({
                                            variant: "destructive",
                                            title: "Error",
                                            description: "Cannot undo merge action (missing link)."
                                        });
                                        return p;
                                    }
                                    // Find the resulting merged item and the original items using the mergeEventId
                                    itemsToRemove = updatedBacklog.filter({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (item)=>item.mergeEventId === mergeEventId && !item.historyStatus
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]); // The non-historical item with the event ID is the result
                                    itemsToRestore = updatedBacklog.filter({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (item)=>item.mergeEventId === mergeEventId && item.historyStatus === 'Merge'
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]); // Original items have status 'Merge' and the event ID
                                } else if (triggerItem.splitFromId) {
                                    undoneActionType = 'Split';
                                    // Find the original historical item that was split
                                    originalItemToRestore = updatedBacklog.find({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (item)=>item.id === triggerItem.splitFromId && item.historyStatus === 'Split'
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]);
                                    if (!originalItemToRestore) {
                                        console.error("Cannot undo split: Original item not found for split item", taskId);
                                        showToast({
                                            variant: "destructive",
                                            title: "Error",
                                            description: "Cannot undo split action (original missing)."
                                        });
                                        return p;
                                    }
                                    // Find all items resulting from that split (including the trigger item itself)
                                    itemsToRemove = updatedBacklog.filter({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (item)=>item.splitFromId === originalItemToRestore.id
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]);
                                } else if (triggerItem.mergeEventId && !triggerItem.historyStatus) {
                                    undoneActionType = 'Merge';
                                    mergeEventId = triggerItem.mergeEventId;
                                    itemsToRemove = [
                                        triggerItem
                                    ]; // The item itself is the result to remove
                                    itemsToRestore = updatedBacklog.filter({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (item)=>item.mergeEventId === mergeEventId && item.historyStatus === 'Merge'
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]); // Find originals via event ID
                                } else {
                                    console.error("Item not eligible for undo:", taskId, triggerItem);
                                    showToast({
                                        variant: "destructive",
                                        title: "Error",
                                        description: "Cannot undo this action (item not eligible)."
                                    });
                                    return p;
                                }
                                // Set details for toast message based on the action type and trigger item
                                if (undoneActionType === 'Split') {
                                    undoneItemDetails = originalItemToRestore ? `${originalItemToRestore.backlogId} (${originalItemToRestore.title || 'No Title'})` : `Split items related to ${triggerItem.backlogId}`;
                                } else if (undoneActionType === 'Merge') {
                                    undoneItemDetails = mergeEventId ? `Merged Items (Event: ${mergeEventId})` : `Merge related to ${triggerItem.backlogId}`;
                                }
                                // Perform the updates only if an action type was determined
                                if (undoneActionType) {
                                    projectUpdated = true;
                                    actionSuccess = true; // Assume success unless checks fail
                                    // IDs of items to be removed
                                    const removedIdsSet = new Set(itemsToRemove.map({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (t)=>t.id
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]));
                                    removedItemIds = itemsToRemove.map({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (t)=>t.backlogId || t.id
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]); // Store IDs for toast
                                    // Filter out the items created by the action
                                    updatedBacklog = updatedBacklog.filter({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (item)=>!removedIdsSet.has(item.id)
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]);
                                    // IDs of items to be restored (either original split parent or original merge children)
                                    const itemsToMakeActive = undoneActionType === 'Split' ? [
                                        originalItemToRestore
                                    ] : itemsToRestore;
                                    const restoredIdsSet = new Set(itemsToMakeActive.filter(Boolean).map({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (t)=>t.id
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]));
                                    restoredItemIds = itemsToMakeActive.filter(Boolean).map({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (t)=>t.backlogId || t.id
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]); // Store IDs for toast
                                    // Restore original items: Remove historyStatus and related IDs
                                    updatedBacklog = updatedBacklog.map({
                                        "Home.useCallback[handleUndoBacklogAction].updatedProjects": (item)=>{
                                            if (restoredIdsSet.has(item.id)) {
                                                console.log("Restoring item:", item.id, item.backlogId);
                                                return {
                                                    ...item,
                                                    historyStatus: undefined,
                                                    splitFromId: undefined,
                                                    mergeEventId: undefined,
                                                    movedToSprint: undefined
                                                };
                                            }
                                            return item;
                                        }
                                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]);
                                    // Validation checks
                                    if (undoneActionType === 'Merge' && itemsToRestore.length === 0 && mergeEventId) {
                                        console.error(`Undo Merge: Could not find original items for mergeEventId ${mergeEventId}`);
                                        showToast({
                                            variant: "warning",
                                            title: "Undo Incomplete",
                                            description: "Could not restore original merged items."
                                        });
                                        actionSuccess = false;
                                        return p; // Revert state change
                                    }
                                    if (itemsToRemove.length === 0 && (undoneActionType === 'Split' || undoneActionType === 'Merge')) {
                                        console.warn(`Undo ${undoneActionType}: Could not find the resulting item(s) to remove. Originals restored.`);
                                        showToast({
                                            variant: "warning",
                                            title: "Undo Warning",
                                            description: `Resulting ${undoneActionType === 'Split' ? 'split' : 'merged'} item(s) not found, originals restored.`
                                        });
                                    }
                                    return {
                                        ...p,
                                        backlog: updatedBacklog.sort({
                                            "Home.useCallback[handleUndoBacklogAction].updatedProjects": (a, b)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["taskPriorities"].indexOf(a.priority) - __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["taskPriorities"].indexOf(b.priority) || (a.backlogId ?? '').localeCompare(b.backlogId ?? '')
                                        }["Home.useCallback[handleUndoBacklogAction].updatedProjects"])
                                    };
                                } else {
                                    // Should not reach here if logic above is correct, but acts as a safeguard
                                    console.error("Undo Error: Could not determine action type for item", taskId);
                                    showToast({
                                        variant: "destructive",
                                        title: "Error",
                                        description: "Could not process the undo request."
                                    });
                                    return p;
                                }
                            }
                            return p;
                        }
                    }["Home.useCallback[handleUndoBacklogAction].updatedProjects"]);
                    // Show appropriate toast after the state update attempt
                    if (actionSuccess && undoneItemDetails && undoneActionType) {
                        const restoredCount = restoredItemIds.length;
                        const removedCount = removedItemIds.length;
                        showToast({
                            title: `${undoneActionType} Undone`,
                            description: `Action related to '${undoneItemDetails}' undone. ${restoredCount} item(s) restored, ${removedCount} item(s) removed.`,
                            duration: 5000
                        });
                    } else if (!actionSuccess && undoneActionType) {
                    // Toast for failure might have already been shown, but add a generic one if needed
                    // showToast({ variant: "destructive", title: "Undo Failed", description: "The undo operation could not be completed." });
                    }
                    return projectUpdated ? updatedProjects : prevProjects; // Return original state if no update occurred
                }
            }["Home.useCallback[handleUndoBacklogAction]"]);
        }
    }["Home.useCallback[handleUndoBacklogAction]"], [
        selectedProjectId,
        toast,
        setProjects
    ]); // Added setProjects dependency
    // Handler to add members to the *newly created* project (from dialog)
    const handleAddMembersToNewProject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleAddMembersToNewProject]": (addedMembers)=>{
            if (!newlyCreatedProjectId) return;
            let newProjectName = 'the new project';
            // Wrap state updates in setTimeout to defer execution
            setTimeout({
                "Home.useCallback[handleAddMembersToNewProject]": ()=>{
                    setProjects({
                        "Home.useCallback[handleAddMembersToNewProject]": (prevProjects)=>{
                            const updatedProjects = prevProjects.map({
                                "Home.useCallback[handleAddMembersToNewProject].updatedProjects": (p)=>{
                                    if (p.id === newlyCreatedProjectId) {
                                        newProjectName = p.name; // Capture name
                                        return {
                                            ...p,
                                            members: [
                                                ...p.members || [],
                                                ...addedMembers
                                            ]
                                        };
                                    }
                                    return p;
                                }
                            }["Home.useCallback[handleAddMembersToNewProject].updatedProjects"]);
                            return updatedProjects;
                        }
                    }["Home.useCallback[handleAddMembersToNewProject]"]);
                    toast({
                        title: "Members Added",
                        description: `Members added to project '${newProjectName}'.`
                    });
                    setIsAddMembersDialogOpen(false); // Close the dialog
                    setNewlyCreatedProjectId(null); // Reset the tracked ID
                }
            }["Home.useCallback[handleAddMembersToNewProject]"], 0); // Use 0 timeout to push to the end of the event loop
        }
    }["Home.useCallback[handleAddMembersToNewProject]"], [
        newlyCreatedProjectId,
        toast,
        setProjects,
        setIsAddMembersDialogOpen,
        setNewlyCreatedProjectId
    ]); // Include state setters in dependency array if ESLint requires
    // Handler to delete a sprint
    const handleDeleteSprint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Home.useCallback[handleDeleteSprint]": (sprintNumber)=>{
            if (!selectedProjectId) {
                toast({
                    variant: "destructive",
                    title: "Error",
                    description: "No project selected."
                });
                return;
            }
            let currentProjectName = 'N/A';
            setProjects({
                "Home.useCallback[handleDeleteSprint]": (prevProjects)=>{
                    const updatedProjects = prevProjects.map({
                        "Home.useCallback[handleDeleteSprint].updatedProjects": (p)=>{
                            if (p.id === selectedProjectId) {
                                currentProjectName = p.name; // Capture name
                                const filteredSprints = (p.sprintData.sprints ?? []).filter({
                                    "Home.useCallback[handleDeleteSprint].updatedProjects.filteredSprints": (s)=>s.sprintNumber !== sprintNumber
                                }["Home.useCallback[handleDeleteSprint].updatedProjects.filteredSprints"]); // Handle null/undefined
                                return {
                                    ...p,
                                    sprintData: {
                                        ...p.sprintData ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialSprintData"],
                                        sprints: filteredSprints,
                                        // Recalculate overall metrics if needed
                                        totalStoryPoints: filteredSprints.reduce({
                                            "Home.useCallback[handleDeleteSprint].updatedProjects": (sum, s)=>sum + s.completedPoints
                                        }["Home.useCallback[handleDeleteSprint].updatedProjects"], 0),
                                        daysInSprint: filteredSprints.length > 0 ? Math.max(...filteredSprints.map({
                                            "Home.useCallback[handleDeleteSprint].updatedProjects": (s)=>s.totalDays
                                        }["Home.useCallback[handleDeleteSprint].updatedProjects"])) : 0
                                    }
                                };
                            }
                            return p;
                        }
                    }["Home.useCallback[handleDeleteSprint].updatedProjects"]);
                    return updatedProjects;
                }
            }["Home.useCallback[handleDeleteSprint]"]);
            toast({
                title: "Sprint Deleted",
                description: `Sprint ${sprintNumber} deleted from project '${currentProjectName}'.`
            });
        }
    }["Home.useCallback[handleDeleteSprint]"], [
        selectedProjectId,
        toast
    ]);
    // Export data for the currently selected project
    const handleExport = ()=>{
        if (!selectedProject || !selectedProject.sprintData?.sprints?.length && !selectedProject.members?.length && !selectedProject.holidayCalendars?.length && !selectedProject.teams?.length && !selectedProject.backlog?.length) {
            toast({
                variant: "destructive",
                title: "Error",
                description: `No data available to export for project '${selectedProject?.name ?? 'N/A'}'.`
            });
            return;
        }
        try {
            const wb = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].book_new();
            // Sprint Summary Sheet
            if (selectedProject.sprintData?.sprints?.length > 0) {
                const summaryData = selectedProject.sprintData.sprints.map((s)=>({
                        'SprintNumber': s.sprintNumber,
                        'StartDate': s.startDate,
                        'EndDate': s.endDate,
                        'Duration': s.duration,
                        'Status': s.status,
                        'TotalCommitment': s.committedPoints,
                        'TotalDelivered': s.completedPoints
                    }));
                const wsSummary = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].json_to_sheet(summaryData);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].book_append_sheet(wb, wsSummary, 'Sprint Summary');
            }
            // Planning Sheets (Summary and Tasks)
            const planningExists = selectedProject.sprintData?.sprints?.some((s)=>s.planning && (s.planning.goal || s.planning.newTasks?.length > 0 || s.planning.spilloverTasks?.length > 0 || s.planning.definitionOfDone || s.planning.testingStrategy));
            if (planningExists) {
                const planningSummaryData = [];
                const planningTasksData = [];
                selectedProject.sprintData.sprints.forEach((sprint)=>{
                    if (sprint.planning) {
                        planningSummaryData.push({
                            'SprintNumber': sprint.sprintNumber,
                            'Goal': sprint.planning.goal,
                            'DefinitionOfDone': sprint.planning.definitionOfDone,
                            'TestingStrategy': sprint.planning.testingStrategy
                        });
                        // Helper function to map task to export row
                        const mapTaskToRow = (task, type)=>({
                                'SprintNumber': sprint.sprintNumber,
                                'Type': type,
                                'TaskID': task.id,
                                'TicketNumber': task.ticketNumber,
                                'BacklogID': task.backlogId,
                                'Title': task.title,
                                'Description': task.description,
                                'StoryPoints': task.storyPoints,
                                'DevEstTime': task.devEstimatedTime,
                                'QAEstTime': task.qaEstimatedTime,
                                'BufferTime': task.bufferTime,
                                'Assignee': task.assignee,
                                'Reviewer': task.reviewer,
                                'Status': task.status,
                                'StartDate': task.startDate,
                                'Priority': task.priority
                            });
                        (sprint.planning.newTasks || []).forEach((task)=>planningTasksData.push(mapTaskToRow(task, 'New')));
                        (sprint.planning.spilloverTasks || []).forEach((task)=>planningTasksData.push(mapTaskToRow(task, 'Spillover')));
                    }
                });
                if (planningSummaryData.length > 0) {
                    const wsPlanningSummary = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].json_to_sheet(planningSummaryData);
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].book_append_sheet(wb, wsPlanningSummary, 'Planning Summary');
                }
                if (planningTasksData.length > 0) {
                    const wsPlanningTasks = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].json_to_sheet(planningTasksData);
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].book_append_sheet(wb, wsPlanningTasks, 'Planning Tasks');
                }
            }
            // Backlog Sheet
            if (selectedProject.backlog && selectedProject.backlog.length > 0) {
                const backlogData = selectedProject.backlog.map((task)=>({
                        'BacklogItemID': task.id,
                        'BacklogID': task.backlogId,
                        'Title': task.title,
                        'Description': task.description,
                        'TaskType': task.taskType,
                        'Priority': task.priority,
                        'Initiator': task.initiator,
                        'CreatedDate': task.createdDate,
                        'StoryPoints': task.storyPoints,
                        'DependsOn': (task.dependsOn || []).join(', '),
                        'MovedToSprint': task.movedToSprint ?? '',
                        'HistoryStatus': task.historyStatus ?? '',
                        'NeedsGrooming': task.needsGrooming ? 'Yes' : 'No',
                        'ReadyForSprint': task.readyForSprint ? 'Yes' : 'No',
                        'SplitFromID': task.splitFromId ?? '',
                        'MergeEventID': task.mergeEventId ?? ''
                    }));
                const wsBacklog = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].json_to_sheet(backlogData);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].book_append_sheet(wb, wsBacklog, 'Backlog');
            }
            // Members Sheet
            if (selectedProject.members && selectedProject.members.length > 0) {
                const membersData = selectedProject.members.map((m)=>({
                        'MemberID': m.id,
                        'Name': m.name,
                        'Role': m.role,
                        'HolidayCalendarID': m.holidayCalendarId
                    }));
                const wsMembers = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].json_to_sheet(membersData);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].book_append_sheet(wb, wsMembers, 'Members');
            }
            // Holiday Calendars Sheet
            if (selectedProject.holidayCalendars && selectedProject.holidayCalendars.length > 0) {
                const calendarsData = [];
                selectedProject.holidayCalendars.forEach((cal)=>{
                    cal.holidays.forEach((holiday)=>{
                        calendarsData.push({
                            'CalendarID': cal.id,
                            'CalendarName': cal.name,
                            'CountryCode': cal.countryCode,
                            'HolidayID': holiday.id,
                            'HolidayName': holiday.name,
                            'HolidayDate': holiday.date
                        });
                    });
                    // Add row for calendar itself if it has no holidays
                    if (cal.holidays.length === 0) {
                        calendarsData.push({
                            'CalendarID': cal.id,
                            'CalendarName': cal.name,
                            'CountryCode': cal.countryCode,
                            'HolidayID': '',
                            'HolidayName': '',
                            'HolidayDate': ''
                        });
                    }
                });
                const wsHolidays = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].json_to_sheet(calendarsData);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].book_append_sheet(wb, wsHolidays, 'Holiday Calendars');
            }
            // Teams Sheet
            if (selectedProject.teams && selectedProject.teams.length > 0) {
                const teamsData = [];
                selectedProject.teams.forEach((team)=>{
                    team.members.forEach((tm)=>{
                        teamsData.push({
                            'TeamID': team.id,
                            'TeamName': team.name,
                            'LeadMemberID': team.leadMemberId,
                            'MemberID': tm.memberId
                        });
                    });
                    // Add row for team itself if it has no members
                    if (team.members.length === 0) {
                        teamsData.push({
                            'TeamID': team.id,
                            'TeamName': team.name,
                            'LeadMemberID': team.leadMemberId,
                            'MemberID': ''
                        });
                    }
                });
                const wsTeams = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].json_to_sheet(teamsData);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utils"].book_append_sheet(wb, wsTeams, 'Teams');
            }
            const projectNameSlug = selectedProject.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$xlsx$2f$xlsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["writeFile"])(wb, `sprint_stats_${projectNameSlug}_report.xlsx`);
            toast({
                title: "Success",
                description: `Data for project '${selectedProject.name}' exported to Excel.`
            });
        } catch (error) {
            console.error("Error exporting data:", error);
            toast({
                variant: "destructive",
                title: "Error",
                description: "Failed to export data."
            });
        }
    };
    // Handle creating a new project
    const handleCreateNewProject = ()=>{
        const trimmedName = newProjectName.trim();
        if (!trimmedName) {
            toast({
                variant: "destructive",
                title: "Error",
                description: "Project name cannot be empty."
            });
            return;
        }
        if (projects.some((p)=>p.name.toLowerCase() === trimmedName.toLowerCase())) {
            toast({
                variant: "destructive",
                title: "Error",
                description: `Project with name "${trimmedName}" already exists.`
            });
            return;
        }
        const newProject = {
            id: `proj_${Date.now()}`,
            name: trimmedName,
            sprintData: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$sprint$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialSprintData"],
            members: [],
            holidayCalendars: [],
            teams: [],
            backlog: []
        };
        // Update projects state first
        setProjects((prevProjects)=>[
                ...prevProjects,
                newProject
            ]);
        setSelectedProjectId(newProject.id);
        setNewProjectName('');
        setIsNewProjectDialogOpen(false);
        setNewlyCreatedProjectId(newProject.id); // Track the new project ID for dialog
        setActiveTab("dashboard"); // Set dashboard as active after creating
        // Defer the toast and dialog opening slightly
        setTimeout(()=>{
            toast({
                title: "Project Created",
                description: `Project "${trimmedName}" created successfully.`
            });
            setIsAddMembersDialogOpen(true); // Open the dialog AFTER state update
        }, 50); // Increased timeout slightly
    };
    // Handler to open the delete project confirmation dialog
    const handleOpenDeleteDialog = (projectId)=>{
        if (!projectId) return;
        setProjectToDeleteId(projectId);
        setConfirmProjectName(''); // Reset confirmation input
        setIsDeleteDialogOpen(true);
    };
    // Handler to confirm and delete a project
    const handleConfirmDeleteProject = ()=>{
        if (!projectToDeleteId) return;
        const project = projects.find((p)=>p.id === projectToDeleteId);
        if (!project) {
            toast({
                variant: "destructive",
                title: "Error",
                description: "Project not found."
            });
            setIsDeleteDialogOpen(false);
            setProjectToDeleteId(null);
            return;
        }
        if (confirmProjectName.trim().toLowerCase() !== project.name.toLowerCase()) {
            toast({
                variant: "destructive",
                title: "Confirmation Failed",
                description: "Project name does not match."
            });
            return;
        }
        setProjects((prevProjects)=>prevProjects.filter((p)=>p.id !== projectToDeleteId));
        // If the deleted project was the selected one, select the first available project or null
        if (selectedProjectId === projectToDeleteId) {
            setSelectedProjectId(projects.length > 1 ? projects.find((p)=>p.id !== projectToDeleteId)?.id ?? null : null);
        }
        toast({
            title: "Project Deleted",
            description: `Project "${project.name}" has been deleted.`
        });
        setIsDeleteDialogOpen(false);
        setProjectToDeleteId(null);
    };
    // Define the tab structure
    const tabsConfig = {
        dashboard: {
            label: "Dashboard",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$dashboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutDashboard$3e$__["LayoutDashboard"],
            component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$dashboard$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
        },
        sprints: {
            label: "Sprints",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$iteration$2d$cw$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IterationCw$3e$__["IterationCw"],
            subTabs: {
                summary: {
                    label: "Summary",
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"],
                    component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$sprints$2f$sprint$2d$summary$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                },
                planning: {
                    label: "Planning",
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__["NotebookPen"],
                    component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$sprints$2f$sprint$2d$planning$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                },
                retrospective: {
                    label: "Retrospective",
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$git$2d$commit$2d$vertical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GitCommitVertical$3e$__["GitCommitVertical"],
                    component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$sprints$2f$sprint$2d$retrospective$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                }
            }
        },
        backlog: {
            label: "Backlog",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Layers$3e$__["Layers"],
            subTabs: {
                management: {
                    label: "Management",
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__["Package"],
                    component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$backlog$2f$backlog$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                },
                grooming: {
                    label: "Grooming",
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__["Edit"],
                    component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$backlog$2f$backlog$2d$grooming$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                },
                history: {
                    label: "History",
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$history$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__History$3e$__["History"],
                    component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$backlog$2f$history$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                }
            }
        },
        analytics: {
            label: "Analytics",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChartBig$3e$__["BarChartBig"],
            subTabs: {
                charts: {
                    label: "Charts",
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$no$2d$axes$2d$column$2d$increasing$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart$3e$__["BarChart"],
                    component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$analytics$2d$charts$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                },
                reports: {
                    label: "Reports",
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListPlus$3e$__["ListPlus"],
                    component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$analytics$2f$analytics$2d$reports$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                }
            }
        },
        teams: {
            label: "Teams",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"],
            subTabs: {
                members: {
                    label: "Members",
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"],
                    component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$teams$2f$members$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                },
                teams: {
                    label: "Teams",
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2d$round$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UsersRound$3e$__["UsersRound"],
                    component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$teams$2f$teams$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                }
            }
        },
        settings: {
            label: "Settings",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"],
            subTabs: {
                holidays: {
                    label: "Holidays",
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2d$days$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarDays$3e$__["CalendarDays"],
                    component: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$settings$2f$holidays$2d$tab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                }
            }
        }
    };
    // Render the currently active tab content
    const renderActiveTabContent = ()=>{
        if (!selectedProject) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                className: "flex flex-col items-center justify-center min-h-[400px] border-dashed border-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                    className: "text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                            children: "No Project Selected"
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 1523,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                            children: "Please select a project from the dropdown above, or create a new one."
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 1524,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 1522,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 1521,
                columnNumber: 9
            }, this);
        }
        const [mainKey, subKey] = activeTab.split('/');
        const mainConfig = tabsConfig[mainKey];
        if (!mainConfig) return null; // Should not happen if activeTab is valid
        let ActiveComponent;
        let componentProps = {
            projectId: selectedProject.id,
            projectName: selectedProject.name
        };
        if (mainConfig.subTabs && subKey) {
            const subConfig = mainConfig.subTabs[subKey];
            if (!subConfig) return null; // Invalid sub-tab
            ActiveComponent = subConfig.component;
            // Add specific props based on the sub-tab component
            switch(`${mainKey}/${subKey}`){
                case 'sprints/summary':
                    componentProps = {
                        ...componentProps,
                        sprintData: selectedProject.sprintData,
                        onDeleteSprint: handleDeleteSprint
                    };
                    break;
                case 'sprints/planning':
                    componentProps = {
                        ...componentProps,
                        sprints: selectedProject.sprintData.sprints ?? [],
                        onSavePlanning: handleSavePlanningAndUpdateStatus,
                        onCreateAndPlanSprint: handleCreateAndPlanSprint,
                        members: selectedProject.members ?? [],
                        holidayCalendars: selectedProject.holidayCalendars ?? [],
                        teams: selectedProject.teams ?? [],
                        backlog: selectedProject.backlog?.filter((task)=>!task.historyStatus && task.readyForSprint) ?? [],
                        onRevertTask: handleRevertTaskToBacklog,
                        onCompleteSprint: handleCompleteSprint
                    };
                    break;
                case 'sprints/retrospective':
                    componentProps = {
                        ...componentProps,
                        sprints: selectedProject.sprintData.sprints ?? []
                    };
                    break;
                case 'backlog/management':
                    componentProps = {
                        ...componentProps,
                        initialBacklog: selectedProject.backlog ?? [],
                        onSaveNewItems: handleSaveNewBacklogItems,
                        onUpdateSavedItem: handleUpdateSavedBacklogItem,
                        onDeleteSavedItem: handleDeleteSavedBacklogItem,
                        members: selectedProject.members ?? [],
                        sprints: selectedProject.sprintData.sprints ?? [],
                        onMoveToSprint: handleMoveToSprint,
                        generateNextBacklogId: generateNextBacklogIdHelper
                    };
                    break;
                case 'backlog/grooming':
                    componentProps = {
                        ...componentProps,
                        initialBacklog: selectedProject.backlog ?? [],
                        // Grooming usually modifies existing items, so reuse update handler or create specific one
                        onSaveBacklog: (groomedBacklog)=>{
                            // Determine which items were updated in grooming
                            const updatedIds = new Set(groomedBacklog.filter((t)=>!t.historyStatus).map((t)=>t.id));
                            const combined = [
                                ...groomedBacklog,
                                ...selectedProject.backlog?.filter((t)=>t.historyStatus && !groomedBacklog.some((gt)=>gt.id === t.id)) || []
                            ];
                            setProjects((prev)=>prev.map((p)=>p.id === selectedProjectId ? {
                                        ...p,
                                        backlog: combined
                                    } : p));
                            toast({
                                title: "Backlog Groomed",
                                description: "Changes saved."
                            });
                        },
                        onSplitBacklogItem: handleSplitBacklogItem,
                        onMergeBacklogItems: handleMergeBacklogItems,
                        onUndoBacklogAction: handleUndoBacklogAction,
                        generateNextBacklogId: generateNextBacklogIdHelper,
                        allProjectBacklogItems: selectedProject.backlog ?? []
                    };
                    break;
                case 'backlog/history':
                    componentProps = {
                        ...componentProps,
                        historyItems: selectedProject.backlog?.filter((task)=>!!task.historyStatus) ?? [],
                        onUndoBacklogAction: handleUndoBacklogAction
                    };
                    break;
                case 'analytics/charts':
                    componentProps = {
                        ...componentProps,
                        sprintData: selectedProject.sprintData,
                        members: selectedProject.members ?? []
                    };
                    break;
                case 'analytics/reports':
                    componentProps = {
                        ...componentProps,
                        sprintData: selectedProject.sprintData
                    };
                    break;
                case 'teams/members':
                    componentProps = {
                        ...componentProps,
                        initialMembers: selectedProject.members ?? [],
                        onSaveMembers: handleSaveMembers,
                        holidayCalendars: selectedProject.holidayCalendars ?? []
                    };
                    break;
                case 'teams/teams':
                    componentProps = {
                        ...componentProps,
                        initialTeams: selectedProject.teams ?? [],
                        allMembers: selectedProject.members ?? [],
                        onSaveTeams: handleSaveTeams
                    };
                    break;
                case 'settings/holidays':
                    componentProps = {
                        ...componentProps,
                        initialCalendars: selectedProject.holidayCalendars ?? [],
                        onSaveCalendars: handleSaveHolidayCalendars
                    };
                    break;
                default:
                    ActiveComponent = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: "Unknown Tab"
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 1640,
                            columnNumber: 41
                        }, this);
                    componentProps = {};
                    break;
            }
        } else {
            // Handle main tabs without sub-tabs (Dashboard)
            ActiveComponent = mainConfig.component;
            if (mainKey === 'dashboard') {
                componentProps = {
                    ...componentProps,
                    sprintData: selectedProject.sprintData
                };
            }
        // Add props for other main tabs if needed
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ActiveComponent, {
            ...componentProps
        }, void 0, false, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 1654,
            columnNumber: 12
        }, this);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col min-h-screen bg-background",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "sticky top-0 z-10 flex items-center justify-between p-4 bg-card border-b shadow-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-2xl font-semibold text-primary",
                                children: "Project Prism"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 1662,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: selectedProjectId ?? undefined,
                                onValueChange: (value)=>{
                                    if (value === 'loading') return; // Prevent selecting the loading indicator
                                    console.log(`Project selected: ${value}`);
                                    setSelectedProjectId(value);
                                    setActiveTab("dashboard"); // Reset to dashboard tab on project change
                                },
                                disabled: isLoading || projects.length === 0,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        className: "w-[200px]",
                                        children: [
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                                placeholder: isLoading ? "Loading..." : "Select a project"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 1674,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 1673,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectGroup"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectLabel"], {
                                                    children: "Projects"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 1678,
                                                    columnNumber: 25
                                                }, this),
                                                isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                    value: "loading",
                                                    disabled: true,
                                                    children: "Loading projects..."
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 1680,
                                                    columnNumber: 29
                                                }, this) : projects.length > 0 ? projects.map((project)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between pr-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                                value: project.id,
                                                                className: "flex-1",
                                                                children: [
                                                                    " ",
                                                                    project.name
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/page.tsx",
                                                                lineNumber: 1684,
                                                                columnNumber: 37
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                variant: "ghost",
                                                                size: "icon",
                                                                className: "h-6 w-6 ml-2 text-muted-foreground hover:text-destructive",
                                                                onClick: (e)=>{
                                                                    e.stopPropagation(); // Prevent Select from closing
                                                                    handleOpenDeleteDialog(project.id);
                                                                },
                                                                "aria-label": `Delete project ${project.name}`,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                    className: "h-4 w-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/page.tsx",
                                                                    lineNumber: 1697,
                                                                    columnNumber: 41
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/page.tsx",
                                                                lineNumber: 1687,
                                                                columnNumber: 37
                                                            }, this)
                                                        ]
                                                    }, project.id, true, {
                                                        fileName: "[project]/src/app/page.tsx",
                                                        lineNumber: 1683,
                                                        columnNumber: 33
                                                    }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                    value: "no-projects",
                                                    disabled: true,
                                                    children: "No projects yet"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 1702,
                                                    columnNumber: 29
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 1677,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 1676,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 1663,
                                columnNumber: 14
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
                                open: isNewProjectDialogOpen,
                                onOpenChange: setIsNewProjectDialogOpen,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTrigger"], {
                                        asChild: true,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            variant: "outline",
                                            size: "sm",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusCircle$3e$__["PlusCircle"], {
                                                    className: "mr-2 h-4 w-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 1709,
                                                    columnNumber: 57
                                                }, this),
                                                " New Project"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 1709,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 1708,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
                                        className: "sm:max-w-[425px]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogHeader"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                                                        children: "Create New Project"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/page.tsx",
                                                        lineNumber: 1713,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogDescription"], {
                                                        children: "Enter a name for your new project. Click create when you're done."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/page.tsx",
                                                        lineNumber: 1714,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 1712,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid gap-4 py-4",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid grid-cols-4 items-center gap-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                            htmlFor: "name",
                                                            className: "text-right",
                                                            children: "Name"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/page.tsx",
                                                            lineNumber: 1720,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                            id: "name",
                                                            value: newProjectName,
                                                            onChange: (e)=>setNewProjectName(e.target.value),
                                                            className: "col-span-3",
                                                            placeholder: "E.g., Website Redesign",
                                                            autoFocus: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/page.tsx",
                                                            lineNumber: 1723,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 1719,
                                                    columnNumber: 25
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 1718,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogFooter"], {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                    type: "button",
                                                    onClick: handleCreateNewProject,
                                                    children: "Create Project"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 1734,
                                                    columnNumber: 25
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 1733,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 1711,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 1707,
                                columnNumber: 14
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 1661,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4",
                        children: [
                            selectedProject && (selectedProject.sprintData?.sprints?.length > 0 || selectedProject.members?.length > 0 || selectedProject.holidayCalendars?.length > 0 || selectedProject.teams?.length > 0 || selectedProject.backlog?.length > 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: handleExport,
                                variant: "outline",
                                size: "sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                        className: "mr-2 h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 1743,
                                        columnNumber: 15
                                    }, this),
                                    "Export Project Data"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 1742,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$mode$2d$toggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModeToggle"], {}, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 1747,
                                columnNumber: 11
                            }, this),
                            " "
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 1740,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 1660,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertDialog"], {
                open: isDeleteDialogOpen,
                onOpenChange: setIsDeleteDialogOpen,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertDialogContent"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertDialogHeader"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertDialogTitle"], {
                                    children: [
                                        'Delete Project "',
                                        projects.find((p)=>p.id === projectToDeleteId)?.name,
                                        '"?'
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 1755,
                                    columnNumber: 20
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertDialogDescription"], {
                                    children: [
                                        "This action cannot be undone. This will permanently delete the project and all its associated data (sprints, backlog, members, etc.).",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 1758,
                                            columnNumber: 24
                                        }, this),
                                        "To confirm, please type the project name below:",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            className: "block mt-1",
                                            children: projects.find((p)=>p.id === projectToDeleteId)?.name
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 1760,
                                            columnNumber: 24
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 1756,
                                    columnNumber: 20
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 1754,
                            columnNumber: 16
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "py-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                id: "confirm-project-name",
                                value: confirmProjectName,
                                onChange: (e)=>setConfirmProjectName(e.target.value),
                                placeholder: "Type project name to confirm",
                                className: "mt-2"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 1764,
                                columnNumber: 21
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 1763,
                            columnNumber: 16
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertDialogFooter"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertDialogCancel"], {
                                    onClick: ()=>setProjectToDeleteId(null),
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 1773,
                                    columnNumber: 20
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertDialogAction"], {
                                    onClick: handleConfirmDeleteProject,
                                    disabled: confirmProjectName.trim().toLowerCase() !== (projects.find((p)=>p.id === projectToDeleteId)?.name.toLowerCase() ?? ' '),
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buttonVariants"])({
                                        variant: "destructive"
                                    })),
                                    children: "Delete Project"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 1774,
                                    columnNumber: 20
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 1772,
                            columnNumber: 16
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 1753,
                    columnNumber: 12
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 1752,
                columnNumber: 8
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$add$2d$members$2d$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isAddMembersDialogOpen,
                onOpenChange: setIsAddMembersDialogOpen,
                onSaveMembers: handleAddMembersToNewProject,
                existingMembers: [],
                projectId: newlyCreatedProjectId
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 1786,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "flex-1 p-6",
                children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                    className: "flex flex-col items-center justify-center min-h-[400px] border-dashed border-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                    children: "Loading Project Data..."
                                }, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 1799,
                                    columnNumber: 22
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                    children: "Please wait while the application loads."
                                }, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 1800,
                                    columnNumber: 22
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 1798,
                            columnNumber: 18
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {}, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 1802,
                            columnNumber: 19
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 1797,
                    columnNumber: 14
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tabs"], {
                    value: activeMainTab,
                    onValueChange: handleMainTabChange,
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsList"], {
                            className: "grid w-full grid-cols-6 mb-6",
                            children: Object.entries(tabsConfig).map(([key, config])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                    value: key,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(config.icon, {
                                            className: "mr-2 h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 1812,
                                            columnNumber: 25
                                        }, this),
                                        " ",
                                        config.label
                                    ]
                                }, key, true, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 1811,
                                    columnNumber: 22
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 1809,
                            columnNumber: 16
                        }, this),
                        selectedProject ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4",
                            children: [
                                tabsConfig[activeMainTab]?.subTabs && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tabs"], {
                                    value: activeTab,
                                    onValueChange: setActiveTab,
                                    className: "w-full mb-6",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsList"], {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("grid w-full", // Adjust grid cols dynamically based on the number of subtabs
                                        `grid-cols-${Object.keys(tabsConfig[activeMainTab].subTabs).length}`),
                                        children: Object.entries(tabsConfig[activeMainTab].subTabs).map(([subKey, subConfig])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                value: `${activeMainTab}/${subKey}`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(subConfig.icon, {
                                                        className: "mr-2 h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/page.tsx",
                                                        lineNumber: 1830,
                                                        columnNumber: 44
                                                    }, this),
                                                    " ",
                                                    subConfig.label
                                                ]
                                            }, `${activeMainTab}/${subKey}`, true, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 1829,
                                                columnNumber: 41
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 1823,
                                        columnNumber: 33
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 1822,
                                    columnNumber: 30
                                }, this),
                                renderActiveTabContent()
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 1819,
                            columnNumber: 21
                        }, this) : // Render the "No Project Selected" card if no project is selected
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                            className: "flex flex-col items-center justify-center min-h-[400px] border-dashed border-2 mt-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                    className: "text-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                            children: "No Project Selected"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 1845,
                                            columnNumber: 28
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                            children: "Please select a project from the dropdown above, or create a new one."
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 1846,
                                            columnNumber: 28
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 1844,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {}, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 1848,
                                    columnNumber: 26
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 1843,
                            columnNumber: 22
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 1807,
                    columnNumber: 14
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 1795,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                className: "text-center p-4 text-xs text-muted-foreground border-t",
                children: "Project Prism - Agile Reporting Made Easy"
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 1857,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 1659,
        columnNumber: 5
    }, this);
}
_s(Home, "iydNFKhUxGI3uHiLShodZlbOX94=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app_page_tsx_b025fed5._.js.map