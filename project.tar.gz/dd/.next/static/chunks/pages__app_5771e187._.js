(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__app_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__app_5771e187._.js",
  "chunks": [
    "static/chunks/[root of the server]__3a40d6d2._.js",
    "static/chunks/node_modules_react_b2385d85._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
    "static/chunks/node_modules_react-dom_f14d0471._.js",
    "static/chunks/node_modules_69e050bc._.js",
    "static/chunks/[root of the server]__49fd8634._.js"
  ],
  "source": "entry"
});
