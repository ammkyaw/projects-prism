(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_93c228b9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_93c228b9._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_9696206a._.js",
    "static/chunks/src_components_ui_bb8db538._.js",
    "static/chunks/src_components_backlog_8d50d52b._.js",
    "static/chunks/src_components_sprints_3379dafd._.js",
    "static/chunks/src_components_45664a4f._.js",
    "static/chunks/src_app_page_tsx_b025fed5._.js",
    "static/chunks/src_types_sprint-data_ts_63bc64d1._.js",
    "static/chunks/node_modules_xlsx_xlsx_mjs_ad755052._.js",
    "static/chunks/node_modules_lodash_471b18fc._.js",
    "static/chunks/node_modules_recharts_es6_45bbad69._.js",
    "static/chunks/node_modules_date-fns_22636fe3._.js",
    "static/chunks/node_modules_react-day-picker_dist_index_esm_9fc30424.js",
    "static/chunks/node_modules_@radix-ui_08e5f413._.js",
    "static/chunks/node_modules_@floating-ui_9ec1fa39._.js",
    "static/chunks/node_modules_4a025d3e._.js"
  ],
  "source": "dynamic"
});
