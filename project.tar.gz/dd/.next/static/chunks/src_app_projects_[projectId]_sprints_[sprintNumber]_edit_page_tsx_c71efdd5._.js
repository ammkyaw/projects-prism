(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_projects_[projectId]_sprints_[sprintNumber]_edit_page_tsx_c71efdd5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_projects_[projectId]_sprints_[sprintNumber]_edit_page_tsx_c71efdd5._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c599fd42._.js",
    "static/chunks/node_modules_d351d495._.js",
    "static/chunks/src_4a4e673a._.js"
  ],
  "source": "dynamic"
});
